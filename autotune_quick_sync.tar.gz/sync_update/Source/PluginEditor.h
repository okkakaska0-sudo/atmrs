#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include "PluginProcessor.h"
#include "LookAndFeel.h"

class AutoTuneAudioProcessorEditor : public juce::AudioProcessorEditor,
                                     public juce::Timer,
                                     public juce::Button::Listener
{
public:
    AutoTuneAudioProcessorEditor(AutoTuneAudioProcessor&);
    ~AutoTuneAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;
    void buttonClicked(juce::Button* button) override;

private:
    AutoTuneAudioProcessor& audioProcessor;
    
    // Custom Look and Feel
    ProAutoTuneLookAndFeel lookAndFeel;
    
    // Main controls
    juce::Slider speedSlider;
    juce::Label speedLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> speedAttachment;
    
    juce::Slider amountSlider;
    juce::Label amountLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> amountAttachment;
    
    juce::ComboBox modeSelector;
    juce::Label modeLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> modeAttachment;
    
    juce::ComboBox keySelector;
    juce::Label keyLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> keyAttachment;
    
    juce::ComboBox scaleSelector;
    juce::Label scaleLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> scaleAttachment;
    
    // Preset controls
    juce::TextButton savePresetButton;
    juce::TextButton loadPresetButton;
    juce::ComboBox presetSelector;
    
    // Visual elements
    juce::Rectangle<int> headerArea;
    juce::Rectangle<int> controlsArea;
    juce::Rectangle<int> presetArea;
    
    // Real-time display
    float currentInputLevel = 0.0f;
    float currentOutputLevel = 0.0f;
    std::vector<float> pitchHistory;
    static constexpr int pitchHistorySize = 100;
    
    // Helper methods
    void setupControls();
    void setupLayout();
    void updatePresetList();
    void drawHeader(juce::Graphics& g, const juce::Rectangle<int>& area);
    void drawControls(juce::Graphics& g, const juce::Rectangle<int>& area);
    void drawPresetSection(juce::Graphics& g, const juce::Rectangle<int>& area);
    void drawPitchDisplay(juce::Graphics& g, const juce::Rectangle<int>& area);
    void drawLevelMeters(juce::Graphics& g, const juce::Rectangle<int>& area);
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AutoTuneAudioProcessorEditor)
};
