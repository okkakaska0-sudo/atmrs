#!/bin/bash
echo "🔄 Обновляю AutoTune Plugin..."

# Копируем файлы в проект
rsync -av Source/ /Users/marselmacevans/Downloads/atmrs/Source/
cp CMakeLists_macos_working.txt /Users/marselmacevans/Downloads/atmrs/
cp build_simple.sh /Users/marselmacevans/Downloads/atmrs/
cp *.md /Users/marselmacevans/Downloads/atmrs/

echo "✅ Файлы обновлены! Запускаю сборку..."
cd /Users/marselmacevans/Downloads/atmrs
chmod +x build_simple.sh
./build_simple.sh
